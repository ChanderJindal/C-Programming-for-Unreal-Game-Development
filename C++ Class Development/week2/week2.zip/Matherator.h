// Copyright A.T. Chamillard. All Rights Reserved.

#pragma once

/**
 * The Matherator
*/
class Matherator
{

public:

int GetNthEvenNumber(int N);

int GetTenthEvenNumber();

void PrintMToN(int M , int N);

void PrintOneToTen();

};

